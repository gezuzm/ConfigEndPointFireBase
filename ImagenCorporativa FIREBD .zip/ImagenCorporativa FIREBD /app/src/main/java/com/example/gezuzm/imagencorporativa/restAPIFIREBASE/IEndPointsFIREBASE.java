package com.example.gezuzm.imagencorporativa.restAPIFIREBASE;

import com.example.gezuzm.imagencorporativa.restAPIFIREBASE.model.UsuarioResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by mauricio on 02/10/16.
 */

public interface IEndPointsFIREBASE {



    // con el objeto respuesta
    // con una parametro
    // asi viene del servidor codificada en la URL
    @FormUrlEncoded
    @POST(ConstantesResApiFIREBASE.KEY_POST_ID_TOKEN)
    Call<UsuarioResponse> registrarTokenID(@Field("token") String token);


    // con el objeto respuesta
    // con una parametro
    // asi viene del servidor codificada en la URL
    @FormUrlEncoded
    @POST(ConstantesResApiFIREBASE.KEY_POST_ID_TOKEN)
    Call<UsuarioResponse> registrar_usuario(@Field("token") String id_dispositivo,
                                           @Field("user_instagram") String id_usuario_instagram);

}
