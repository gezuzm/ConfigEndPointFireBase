package com.example.gezuzm.imagencorporativa.restApi.adapter;

import com.example.gezuzm.imagencorporativa.restApi.ConstantesRestApi;
import com.example.gezuzm.imagencorporativa.restApi.IEndpointsApi;
import com.example.gezuzm.imagencorporativa.restApi.deserealizador.MascotaDeserealizador;
import com.example.gezuzm.imagencorporativa.restApi.deserealizador.MascotaDeserializadorID;
import com.example.gezuzm.imagencorporativa.restApi.deserealizador.MascotaDeserializadorMediaUser;
import com.example.gezuzm.imagencorporativa.restApi.model.MascotaResponse;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by mauricio on 19/09/16.
 */
public class RestApiAdapter {

    public IEndpointsApi establecerConexionRestApiInstagram(Gson gson)
    {
        // DESSEARILIZACION
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ConstantesRestApi.ROOT_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        return retrofit.create(IEndpointsApi.class);

    }

    public Gson construyeGsonDeserializadorMediaRecent()
    {
        GsonBuilder gsonBuilder  = new GsonBuilder();
        gsonBuilder.registerTypeAdapter(MascotaResponse.class, new MascotaDeserealizador());

        return gsonBuilder.create();

    }


    public Gson construyeGsonDeserializadorID()
    {
        GsonBuilder gsonBuilder  = new GsonBuilder();
        gsonBuilder.registerTypeAdapter(MascotaResponse.class, new MascotaDeserializadorID());

        return gsonBuilder.create();

    }


    public Gson construyeGsonDeserializadorMediaUser()
    {
        GsonBuilder gsonBuilder  = new GsonBuilder();
        gsonBuilder.registerTypeAdapter(MascotaResponse.class, new MascotaDeserializadorMediaUser());

        return gsonBuilder.create();

    }

}
