package com.example.gezuzm.imagencorporativa;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

/**
 * Created by mauricio on 19/09/16.
 */
public class DetalleMascota extends AppCompatActivity {

        private static final String KEY_EXTRA_URL = "url";
        private static final String KEY_EXTRA_LIKES = "like";
        //private TextView tvNombre;
        //private TextView tvTelefono;
        //private TextView tvEmail;
        private ImageView imgMascotaDetalle;
        private TextView tvNoLikeDetalle;

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_detalle_mascota_foto);

            Bundle extras = getIntent().getExtras();
            String url   = extras.getString(KEY_EXTRA_URL);
            int likes    = extras.getInt(KEY_EXTRA_LIKES);

            tvNoLikeDetalle     = (TextView) findViewById(R.id.tvNoLikeDetalle);
            tvNoLikeDetalle.setText(String.valueOf(likes));

            imgMascotaDetalle = (ImageView) findViewById(R.id.imgMascotaDetalle);


            Picasso.with(this)
                    .load(url)
                    .placeholder(R.drawable.el_escarador)
                    .into(imgMascotaDetalle);


        }

    }
