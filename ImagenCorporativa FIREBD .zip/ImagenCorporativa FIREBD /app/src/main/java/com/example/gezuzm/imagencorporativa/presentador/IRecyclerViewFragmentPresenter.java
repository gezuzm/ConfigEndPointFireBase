package com.example.gezuzm.imagencorporativa.presentador;

/**
 * Created by mauricio on 04/09/16.
 */
public interface IRecyclerViewFragmentPresenter {

    public void obtenerMascotasBaseDatos();

    public void obtenerMediosRecientes();

    public void mostrarMascotasRV();

    public String cargarUsuario();

    public String buscarIDUsuario();

    public String obtenerIdUsuario(String usuario);

    public void obtenerMediaUser(String id);
}
