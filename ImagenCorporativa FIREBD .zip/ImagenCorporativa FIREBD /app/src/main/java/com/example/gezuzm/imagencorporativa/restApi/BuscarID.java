package com.example.gezuzm.imagencorporativa.restApi;

import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import com.example.gezuzm.imagencorporativa.db.ConstructorMascotas;
import com.example.gezuzm.imagencorporativa.pojo.Mascota;
import com.example.gezuzm.imagencorporativa.restApi.adapter.RestApiAdapter;
import com.example.gezuzm.imagencorporativa.restApi.model.MascotaResponse;
import com.google.gson.Gson;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by mauricio on 01/10/16.
 */

public class BuscarID {


    private ConstructorMascotas constructorMascotas;
    private ArrayList<Mascota> mascotas;
    public String id;

    public String obtenerIdUsuario(String usuario )
    {
        //1.- generar el ADAPTADOR con el api de instagram
        RestApiAdapter restApiAdapter = new RestApiAdapter();
        Gson gsonID = restApiAdapter.construyeGsonDeserializadorID();

        // 2.- Ubicamos en el archivo que contiene los ENDPOINTS
        IEndpointsApi iEndpointsApi =  restApiAdapter.establecerConexionRestApiInstagram(gsonID);

        //3.- se almacena en una coleccion de calls
        Call<MascotaResponse> mascotaResponseCall = iEndpointsApi.getId(usuario, ConstantesRestApi.ACCESS_TOKEN);
        //    Call<MascotaResponse>  mascotaResponseCall = iEndpointsApi.getId2();

        //4.- son los eventos que si falla o es saisfactoria
        mascotaResponseCall.enqueue(new Callback<MascotaResponse>() {
            @Override
            public void onResponse(Call<MascotaResponse> call, Response<MascotaResponse> response) {

                // la repsuesta se almacena en el objeto JSON
                MascotaResponse mascotaResponse = response.body();

                mascotas =  mascotaResponse.getMascotas();

                id = mascotas.get(0).getId();

                //Toast.makeText(, "id: " + id, Toast.LENGTH_LONG).show();

                Log.e("EL ID: ---------------", id);
                //obtenerMediaUser();
            }

            @Override
            public void onFailure(Call<MascotaResponse> call, Throwable t) {
                //Toast.makeText(context, "Algo Paso", Toast.LENGTH_LONG).show();

                Log.e("Fallo la coneccion", t.toString());
            }
        });

        return id;

    }




}
