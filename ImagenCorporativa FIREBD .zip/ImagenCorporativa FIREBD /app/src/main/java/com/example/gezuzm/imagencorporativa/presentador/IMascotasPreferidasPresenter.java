package com.example.gezuzm.imagencorporativa.presentador;

/**
 * Created by mauricio on 04/09/16.
 */
public interface IMascotasPreferidasPresenter {

    public void obtenerMascotasBaseDatos();

    public void mostrarMascotasRV();
}
