package com.example.gezuzm.imagencorporativa.restAPIFIREBASE.model;

/**
 * Created by mauricio on 02/10/16.
 */

public class UsuarioResponse {

    private String id;
    private String token;

    private String id_dispositivo;
    private String user_instagram;

    /*
    public UsuarioResponse(String id, String token) {
        this.id = id;
        this.token = token;
    }*/


    public UsuarioResponse( String id_dispositivo, String user_instagram) {
        this.id_dispositivo = id_dispositivo;
        this.user_instagram = user_instagram;
    }

    public UsuarioResponse()
    {

    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUser_instagram() {
        return user_instagram;
    }

    public void setUser_instagram(String user_instagram) {
        this.user_instagram = user_instagram;
    }

    public String getId_dispositivo() {
        return id_dispositivo;
    }

    public void setId_dispositivo(String id_dispositivo) {
        this.id_dispositivo = id_dispositivo;
    }
}
