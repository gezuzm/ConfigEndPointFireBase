package com.example.gezuzm.imagencorporativa;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.gezuzm.imagencorporativa.adapter.PageAdapter;
import com.example.gezuzm.imagencorporativa.fragment.MascotasPreferidas;
import com.example.gezuzm.imagencorporativa.fragment.PerfilFragment;
import com.example.gezuzm.imagencorporativa.fragment.RecyclerViewFragment;
import com.example.gezuzm.imagencorporativa.pojo.Mascota;
import com.example.gezuzm.imagencorporativa.restAPIFIREBASE.IEndPointsFIREBASE;
import com.example.gezuzm.imagencorporativa.restAPIFIREBASE.adapter.RestAPIFIREBASEAdapter;
import com.example.gezuzm.imagencorporativa.restAPIFIREBASE.model.UsuarioResponse;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.internal.ValidateAccountRequest;
import com.google.firebase.iid.FirebaseInstanceId;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    ArrayList<Mascota> arrayMascotas;
    private RecyclerView listaMascotas;     // para usarse como recurso local

    // para el FRAGMENT, utilizar los view
    private Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    /////////////////////////////////

    VariableGlobal g;

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // variables locales
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        viewPager = (ViewPager) findViewById(R.id.viewPager);


        if (toolbar != null)
        {
            //    marca error
            //    setSupportActionBar(toolbar);
        }

//        g.setPrimeraVezValue(true);
//        VariableGlobal variableGlobal = ((VariableGlobal) getBaseContext());// getApplicationContext());
  //      variableGlobal.setPrimeraVezValue(true);

        // conecta los "fragments" y el "viewPager"
        setUpViewPager();



        /*  pasado a archivo FRAGMENT
        //asignar la referencia del recurso al recurso local
        listaMascotas = (RecyclerView) findViewById(R.id.rvMascotas);
        // declara un linearloyout para un mejor acomodo del RecyclerView
        LinearLayoutManager llMascotas = new LinearLayoutManager(this);
        llMascotas.setOrientation(LinearLayout.VERTICAL); // requisito
        listaMascotas.setLayoutManager(llMascotas); // asignarlo al RecyclerView

        // de la clase mascotas
        InicializarListaMascotas();
        // iniciar el adaptador, es necesario para poder usar el RecyclerView
        inicializarAdaptador();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
*/
    }

    // crea los FRAGMENTS
    private ArrayList<Fragment> agregarFragments()
    {
        ArrayList<Fragment> fragments = new ArrayList<>();

        fragments.add(new RecyclerViewFragment());
        fragments.add(new PerfilFragment());

        return fragments;
    }

    // poner en orbita los fragments
    // 1.- configurar el VIEWPAGER
    // 2.- lo agrega al TABLELAYOUT
    private void setUpViewPager()
    {

        viewPager.setAdapter(new PageAdapter(getSupportFragmentManager(), agregarFragments()));
        tabLayout.setupWithViewPager(viewPager);

        tabLayout.getTabAt(0).setIcon(R.drawable.ic_action_casa);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_action_name_dog);

    }

    /*
    private void InicializarListaMascotas() {
        // es nercesario tener una clase
        arrayMascotas = new ArrayList<Mascota>();

        arrayMascotas.add(new Mascota(R.drawable.el_escarador, "Escalador"));
        arrayMascotas.add(new Mascota(R.drawable.cochino_jabato, "Jabato"));
        arrayMascotas.add(new Mascota(R.drawable.feanor, "Feanor"));
        arrayMascotas.add(new Mascota(R.drawable.golden_dragoone, "Drago"));
        arrayMascotas.add(new Mascota(R.drawable.kuaku_, "Kuaku"));
        arrayMascotas.add(new Mascota(R.drawable.nomoon, "Nonito"));
        arrayMascotas.add(new Mascota(R.drawable.pekefux, "Pekefux"));
        arrayMascotas.add(new Mascota(R.drawable.tortuga, "Tortu"));
        arrayMascotas.add(new Mascota(R.drawable.miaumiua_atigrado, "Miaumiau"));
    }


    private void inicializarAdaptador() {
        MascotaAdaptador adaptador = new MascotaAdaptador(arrayMascotas, this);
        listaMascotas.setAdapter(adaptador);

    }

*/
    // ir a la segunda actividad
    private void IrMascotasPreferidas() {
        Intent intent = new Intent(this, MascotasPreferidas.class);

        startActivity(intent);

    }


    // este metodo creara el menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // MENU NORMAL
        getMenuInflater().inflate(R.menu.menu_opciones,menu);

        getMenuInflater().inflate(R.menu.menu_action_view, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        Intent intent;

        switch (item.getItemId())
        {

            case R.id.mIrMascotasPreferidas:

                intent = new Intent(this,MascotasPreferidas.class );
                startActivity(intent);
                break;

            case R.id.mAcercaDe:
                intent = new Intent(this,AcercaDeActivity.class );
                startActivity(intent);
                break;

            case R.id.mContacto:
                intent = new Intent(this,ContactoActivity.class );
                startActivity(intent);
                break;

            case R.id.mConfigurarCuenta:
                intent = new Intent(this,ConfigurarCuenta.class);
                startActivity(intent);
                break;

            case R.id.mRecibirNotificaciones:
                enviarUserInstagram();
               // enviarToken();
                //intent = new Intent(this,ConfigurarCuenta.class);
                //startActivity(intent);
                break;


        }

        return super.onOptionsItemSelected(item);
    }


    public void enviarUserInstagram()
    {

        g = VariableGlobal.getInstance();

        String usuario = "";

        if (g.getPrimeraVez() )
        {
            usuario = "pascalitodog";
        }
        else
        {
            SharedPreferences sharedPreferences = getBaseContext().getSharedPreferences("MisPreferencias", Context.MODE_PRIVATE);
            usuario = sharedPreferences.getString("usuario", "pascalitodog");
        }


        String id_dispositivo = FirebaseInstanceId.getInstance().getToken();
        String id_usuario_instagram = usuario;   //solamente para mi usuario

        enviarUserInstagram(id_dispositivo, id_usuario_instagram);

        // Log.d("TOKEN", token);

    }

    private void enviarUserInstagram(String id_dispositivo, String id_usuario_instagram)
    {
       // Log.d("ID_DISPOSITIVO", id_dispositivo);

        RestAPIFIREBASEAdapter restAPIFIREBASEAdapter = new RestAPIFIREBASEAdapter();
        IEndPointsFIREBASE iEndPointsFIREBASE = restAPIFIREBASEAdapter.establecerConexionRestAPI();

        Call<UsuarioResponse> usuarioResponseCall = iEndPointsFIREBASE.registrar_usuario(id_dispositivo, id_usuario_instagram);

        usuarioResponseCall.enqueue(new Callback<UsuarioResponse>() {
            @Override
            public void onResponse(Call<UsuarioResponse> call, Response<UsuarioResponse> response) {

                // la clase es identica a la respuesta
                UsuarioResponse usuarioResponse = response.body();

                if (g.getPrimeraVez())
                {
                    Toast.makeText(getBaseContext(),  "USUARIO DEFAULT....Datos leidos del servidor: id_dispsitivo: " +
                            usuarioResponse.getToken().toString() + ", id_usuario_instagram: " +
                            usuarioResponse.getUser_instagram().toString(), Toast.LENGTH_LONG ).show();
                    
                }
                else
                {
                    Toast.makeText(getBaseContext(),  "Datos leidos del servidor: id_dispsitivo: " +
                            usuarioResponse.getToken().toString() + ", id_usuario_instagram: " +
                            usuarioResponse.getUser_instagram().toString(), Toast.LENGTH_LONG ).show();
                }
                // esto se puede guardar en sharedpreference
                Log.d("ID_FIREBASE", usuarioResponse.getId());
                Log.d("ID_DISPOSITIVO", usuarioResponse.getToken());
                Log.d("ID_USUARIO_INSTAGRAM", usuarioResponse.getUser_instagram());

            }

            @Override
            public void onFailure(Call<UsuarioResponse> call, Throwable t) {

            }
        });

    }



    public void enviarToken()
    {

        String token = FirebaseInstanceId.getInstance().getToken();
        String user_instagram = "pascalitodog";

       enviarTokenRegistro(token, user_instagram);

       // Log.d("TOKEN", token);

    }

    private void enviarTokenRegistro(String token, String user_instagram)
    {
        Log.d("TOKEN", token);

        RestAPIFIREBASEAdapter restAPIFIREBASEAdapter = new RestAPIFIREBASEAdapter();
        IEndPointsFIREBASE iEndPointsFIREBASE = restAPIFIREBASEAdapter.establecerConexionRestAPI();

        Call<UsuarioResponse> usuarioResponseCall = iEndPointsFIREBASE.registrarTokenID(token);

        usuarioResponseCall.enqueue(new Callback<UsuarioResponse>() {
            @Override
            public void onResponse(Call<UsuarioResponse> call, Response<UsuarioResponse> response) {

                // la clase es identica a la respuesta
                UsuarioResponse usuarioResponse = response.body();

                // esto se puede guardar en sharedpreference
                Log.d("ID_FIREBASE", usuarioResponse.getId());
                Log.d("USUARIO_FIREBASE", usuarioResponse.getToken());
               // Log.d("USER_INSTAGRAM", usuarioResponse.getUser_instagram());

            }

            @Override
            public void onFailure(Call<UsuarioResponse> call, Throwable t) {

            }
        });

    }


    /*



    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "Main Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.example.gezuzm.imagencorporativa/http/host/path")
        );
        AppIndex.AppIndexApi.start(client, viewAction);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "Main Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.example.gezuzm.imagencorporativa/http/host/path")
        );
        AppIndex.AppIndexApi.end(client, viewAction);
        client.disconnect();
    } */
}
